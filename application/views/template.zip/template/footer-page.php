<!-- begin:: Footer -->
<div class="kt-footer kt-grid__item" id="kt_footer">
    <div class="kt-container">
        <div class="kt-footer__bottom">
            <div class="kt-footer__copyright">
                2021&nbsp;&copy;&nbsp;<a href="http://maksak.jpm.gov.my" target="_blank" class="kt-link">MAKSAK Malaysia</a>
            </div>
            <div class="kt-footer__menu">
                <a href="#" target="_blank" class="kt-link">Hubungi Admin</a>
            </div>
        </div>
    </div>
</div>

<!-- end:: Footer -->
</div>
</div>
</div>

<!-- end:: Page -->



<!-- begin::Scrolltop -->
<div id="kt_scrolltop" class="kt-scrolltop">
    <i class="fa fa-arrow-up"></i>
</div>

<!-- end::Scrolltop -->